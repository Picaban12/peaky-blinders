#Elytra wings can be 64x32 or 128x64#
#Icons can be 16x16 or 32x32#

The included texture shows the parts of the .png that are being used by minecraft. Everything outside those borders is not rendered in-game.

The BLUE part of the image shows the back of the elytra - this is the part others will see mainly.
The YELLOW edge is the side of the elytra. It renders towards the player.
The GREEN rectangle is the inside of the elytra. This is only seen when the wings are opened, and thus not neccesary
The RED border is the inner edge of the elytra. It is barely seen. 
The MAGENTA part is the bit that renders on top of the elytra. This 'connects' the elytra with the player. It is not neccesary, but recommended to make the elytra more realistic
The CYAN part is the bottom of the elytra. This is not nessesary for smaller wings.

The template makes some kind of box that can be folded together, creating a rectangular box. 